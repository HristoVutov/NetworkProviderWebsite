// MyComponent.d.ts
declare module 'MyComponent' {
    const MyComponent: React.FC;
    export default MyComponent;
    }
    