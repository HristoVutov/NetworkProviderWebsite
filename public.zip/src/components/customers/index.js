import CustomersList from './CustomersList';

export default CustomersList;