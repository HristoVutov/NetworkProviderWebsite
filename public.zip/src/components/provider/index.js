import ProviderMap from './ProviderMap';

export default ProviderMap;